package combiner1;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class comReducer extends Reducer<Text, Text, Text, Text> {
	public void reduce(Text inpK, Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		double max=0.0;
		for(Text x: inpV){
			double each = Double.parseDouble(x.toString());
			if(max<each)
				max=each;
		}
		c.write(inpK, new Text(Double.toString(max)));
	}
}
