import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

class sumReducer extends Reducer<IntWritable, DoubleWritable,IntWritable, DoubleWritable>{
	public void reduce(IntWritable inpK, Iterable<DoubleWritable> inpV, Context c) throws IOException, InterruptedException{
int sum =0;
int count=0;
	for(DoubleWritable x:inpV)
	{
		sum+=x.get();
		count++;
	}
	
	
	c.write((inpK),new DoubleWritable(sum));
}
}
