package log;



import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class logReducer extends Reducer<Text, IntWritable, Text, IntWritable>{
    public void reduce(Text inpk, Iterable<IntWritable> inpv, Context c) throws IOException, InterruptedException{
    	int count=0;
    	for(IntWritable line: inpv)
    	{
    		count = count + line.get();
    		
    	}
    	c.write(inpk, new IntWritable(count));
}
}

