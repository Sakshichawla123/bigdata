package reduceside;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text,Text,Text,Text >{
public void reduce(Text inpk, Iterable<Text> inpv,Context c) throws IOException, InterruptedException{
int count=0;
	String name=null;
	for(Text each: inpv){
		String[] eachVal = each.toString().split(":");
		if(eachVal[0].equals("dept"))
			count++;
		else
			name =eachVal[1];				
	}
	String[] key=inpk.toString().split(":");
	String empname = null;
	c.write(new Text(key[1]), new Text(" "+name+" "+empname));
}


}

