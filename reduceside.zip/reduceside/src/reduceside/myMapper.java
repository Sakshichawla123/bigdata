package reduceside;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable,Text,Text,Text>{
public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
	String value=inpv.toString();
	String eachval[]=value.split(",");
	c.write(new Text("id:"+eachval[0]), new Text("name:"+eachval[1]));
}
}
