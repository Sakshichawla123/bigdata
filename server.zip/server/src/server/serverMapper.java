package server;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class serverMapper extends Mapper<LongWritable, Text, Text, Text>{
	public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
		String value = inpv.toString();
		String eachval[] = value.split(" ");
 	   	   Text outk = new Text(eachval[3]);
 		   c.write(outk,inpv);
 	 
    }
}
