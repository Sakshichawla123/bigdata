package server;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class serverpartition extends Partitioner<Text, Text> {

	@Override
	public int getPartition(Text arg0, Text arg1, int arg2) {
		String arg = arg0.toString();
		if(arg.contains("ERROR"))
			return 0;
		else if(arg.contains("DEBUG"))
			return 1;
		else if(arg.contains("FATAL"))
			return 2;
		else 
			return 3;
		}

}
