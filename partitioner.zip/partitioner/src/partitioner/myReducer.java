package partitioner;


import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
	public void reduce(Text inpK, Iterable<IntWritable> inpV, Context c) throws IOException, InterruptedException{
		for(IntWritable x : inpV)
			c.write(inpK, x);
	}
}

