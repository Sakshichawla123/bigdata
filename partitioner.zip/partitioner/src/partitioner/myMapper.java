package partitioner;


import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
       public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
    	   String value = inpv.toString();
    	   String eachval[] = value.split(",");
    	   int val = Integer.parseInt(eachval[1].trim());
    	   if(val>160)
    	   {
    		   Text outk = new Text(eachval[0]);
    		   IntWritable outv = new IntWritable(val);
    		   c.write(outk,outv);
    	   }
       }
}
