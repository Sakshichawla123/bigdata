package transactions;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class tranxMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
public void tranxMap(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
	String value=inpv.toString();
	String eachval[]=value.split(",");
	double num=Double.parseDouble(eachval[3]);
	if(num>160.00)
	c.write(new Text(eachval[2]), new DoubleWritable(num));		
}
}
