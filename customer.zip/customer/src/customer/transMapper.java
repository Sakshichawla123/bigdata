package customer;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class transMapper extends Mapper<Object,Text,Text,Text>{
public void map(Object key,Text value, Context c) throws IOException, InterruptedException{
	String record =value.toString();
	String val[]=record.split(",");
	c.write(new Text(val[2]), new Text(val[3]));
}
}
