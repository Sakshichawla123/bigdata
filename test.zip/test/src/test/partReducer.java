package test;


import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class partReducer extends Reducer<IntWritable, Text, IntWritable, Text> {
	public void reduce(IntWritable inpK, Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		for(Text x : inpV)
			c.write(inpK,x);
	}
}
