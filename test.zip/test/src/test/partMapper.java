package test;

import java.io.IOException;


import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class partMapper extends Mapper<LongWritable, Text, IntWritable, Text>{
public void map(LongWritable inpk, Text inpv, Context c) throws IOException, InterruptedException{
	String value=inpv.toString();
	String eachval[]=value.split(",");
	Text date = new Text(eachval[1]);
	String val=date.toString();
	String dateval[]=val.split("-");
	int num = Integer.parseInt(dateval[0]);
	IntWritable outK = new IntWritable(num);
	c.write(outK, inpv);
}
}
